# Reelframe — text-to-video SaaS starter

Full stack: FastAPI backend (auth, Stripe subscriptions, Replicate video
generation) + a static frontend (marketing page, sign up/in, dashboard).

This is a working starting point, not a production deployment — read the
"Before you charge real money" section before taking payments live.

## Layout

```
backend/
  app/
    main.py            FastAPI app, CORS, router wiring
    config.py           settings loaded from .env
    models.py            User / Subscription / Generation tables
    routers/auth.py        signup, login, /me
    routers/billing.py     Stripe checkout, customer portal, webhook
    routers/generate.py    create + poll video generations
    services/replicate_service.py   calls Replicate's API
    services/stripe_service.py      calls Stripe's API
  requirements.txt
  .env.example
frontend/
  index.html      marketing page + pricing
  auth.html       sign up / sign in
  dashboard.html  prompt box, generation list, billing portal link
  config.js       API_BASE + fetch helper
```

## 1. Backend setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# now edit .env — see "Fill in your keys" below
```

Run it:

```bash
uvicorn app.main:app --reload --port 8000
```

SQLite (`reelframe.db`) is created automatically on first run. Swap
`DATABASE_URL` in `.env` for Postgres when you're ready for production.

## 2. Fill in your keys

**Replicate** — https://replicate.com/account/api-tokens
- `REPLICATE_API_TOKEN`
- `REPLICATE_MODEL` is pre-set to `wavespeedai/wan-2.1-t2v-720p`. Video
  model slugs on Replicate change often — check
  https://replicate.com/collections/wan-video (or whichever model you want)
  and update this, plus the `input` payload shape in
  `services/replicate_service.py::create_prediction` if the schema differs
  (some models expect `image`, `duration`, `aspect_ratio`, etc.).

**Stripe** — https://dashboard.stripe.com (use test mode keys first)
1. Create one Product ("Reelframe"), with three **recurring monthly Prices**:
   Starter, Studio, Team. Copy each `price_...` ID into `.env`
   (`STRIPE_PRICE_STARTER` / `_STUDIO` / `_TEAM`).
2. `STRIPE_SECRET_KEY` from the API keys page.
3. Webhook: for local dev, install the Stripe CLI and run
   `stripe listen --forward-to localhost:8000/billing/webhook` — it prints a
   `whsec_...` value, put that in `STRIPE_WEBHOOK_SECRET`. In production,
   add a real webhook endpoint in the dashboard pointed at
   `https://yourdomain.com/billing/webhook`, subscribed to at least:
   `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`, `invoice.payment_succeeded`.

**Auth**
- `JWT_SECRET` — any long random string (e.g. `openssl rand -hex 32`).

## 3. Frontend

The frontend is plain static HTML/JS — no build step. Serve it with
anything, e.g.:

```bash
cd frontend
python -m http.server 5500
```

Then open http://localhost:5500/index.html. `frontend/config.js` has
`API_BASE = "http://localhost:8000"` — update it once you deploy the
backend somewhere real, and update `FRONTEND_URL` in the backend `.env` to
match (it's used for CORS and Stripe redirect URLs).

## How it fits together

1. Marketing page → pricing button stores the chosen plan and sends the
   person to `auth.html`.
2. `auth.html` signs them up or logs them in, gets a JWT back, stores it in
   `localStorage`, then immediately calls `POST /billing/checkout` and
   redirects to Stripe Checkout.
3. Stripe redirects back to `dashboard.html` on success. Behind the scenes,
   Stripe's webhook (`checkout.session.completed`) is what actually
   activates the subscription in the database — the redirect itself doesn't
   grant access, so test with the CLI webhook forwarder or nothing will
   activate locally.
4. On the dashboard, submitting a prompt calls `POST /generate`, which
   creates a Replicate prediction and stores it as "processing". The page
   polls `GET /generate/{id}` every few seconds until it's `succeeded` (shows
   the video) or `failed`.
5. "Manage billing" opens the Stripe customer portal, where people can
   upgrade, downgrade, or cancel — Stripe webhooks keep the database in sync.

## Before you charge real money

- Switch Stripe keys from test to live mode, and re-create the products/
  prices/webhook in live mode (they're separate from test mode).
- Move off SQLite to Postgres, and add Alembic migrations instead of
  `create_all()`.
- Put the backend behind HTTPS; browsers will block the frontend from
  calling an `http://` API from an `https://` page.
- Add rate limiting to `/generate` — right now nothing stops a user with an
  active subscription from bursting requests until their quota check
  catches up.
- Consider Replicate **webhooks** instead of client-side polling for
  generation status at scale (see their `webhook` field on prediction
  creation) — polling is fine for an MVP but adds load as usage grows.
- Add a Stripe `customer.subscription.trial_will_end` / failed-payment
  handling path if you offer trials or want dunning emails.
- Review Replicate's and Stripe's own security/production checklists —
  this starter handles the core flow, not every edge case (refunds,
  proration, disputes, model timeouts, etc.).
