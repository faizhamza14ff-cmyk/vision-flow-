// Point this at your running FastAPI backend.
const API_BASE = "http://localhost:8000";

function getToken() {
  return localStorage.getItem("reelframe_token");
}
function setToken(t) {
  localStorage.setItem("reelframe_token", t);
}
function clearToken() {
  localStorage.removeItem("reelframe_token");
}

async function api(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const t = getToken();
    if (t) headers["Authorization"] = `Bearer ${t}`;
  }
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.detail || `Request failed (${res.status})`);
  }
  return data;
}
