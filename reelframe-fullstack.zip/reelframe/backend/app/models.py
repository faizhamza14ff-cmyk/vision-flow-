import uuid
import datetime as dt

from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Float
from sqlalchemy.orm import relationship

from .database import Base


def uid() -> str:
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=uid)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    stripe_customer_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    subscription = relationship("Subscription", back_populates="user", uselist=False)
    generations = relationship("Generation", back_populates="user")


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(String, primary_key=True, default=uid)
    user_id = Column(String, ForeignKey("users.id"), unique=True, nullable=False)

    plan = Column(String, nullable=True)  # "starter" | "studio" | "team"
    status = Column(String, default="inactive")  # mirrors Stripe subscription.status
    stripe_subscription_id = Column(String, nullable=True)
    current_period_end = Column(DateTime, nullable=True)

    seconds_quota = Column(Integer, default=0)
    seconds_used = Column(Float, default=0)

    user = relationship("User", back_populates="subscription")


class Generation(Base):
    __tablename__ = "generations"

    id = Column(String, primary_key=True, default=uid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)

    prompt = Column(String, nullable=False)
    status = Column(String, default="starting")  # starting|processing|succeeded|failed
    replicate_prediction_id = Column(String, nullable=True)
    video_url = Column(String, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    error = Column(String, nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    user = relationship("User", back_populates="generations")
