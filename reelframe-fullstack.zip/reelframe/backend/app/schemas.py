import datetime as dt
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


# --- Auth ---
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class SubscriptionOut(BaseModel):
    plan: Optional[str]
    status: str
    current_period_end: Optional[dt.datetime]
    seconds_quota: int
    seconds_used: float

    class Config:
        from_attributes = True


class UserOut(BaseModel):
    id: str
    email: EmailStr
    created_at: dt.datetime
    subscription: Optional[SubscriptionOut] = None

    class Config:
        from_attributes = True


# --- Billing ---
class CheckoutRequest(BaseModel):
    plan: str  # "starter" | "studio" | "team"


class CheckoutOut(BaseModel):
    checkout_url: str


class PortalOut(BaseModel):
    portal_url: str


# --- Generation ---
class GenerationCreate(BaseModel):
    prompt: str = Field(min_length=3, max_length=1500)


class GenerationOut(BaseModel):
    id: str
    prompt: str
    status: str
    video_url: Optional[str]
    duration_seconds: Optional[float]
    error: Optional[str]
    created_at: dt.datetime

    class Config:
        from_attributes = True
