"""
Thin wrapper around Replicate's REST API.

Docs: https://replicate.com/docs/reference/http
Predictions are asynchronous: you create one, then poll it (or receive a
webhook) until status is "succeeded" or "failed".
"""
import httpx

from ..config import settings


class ReplicateError(RuntimeError):
    pass


def _headers() -> dict:
    if not settings.REPLICATE_API_TOKEN:
        raise ReplicateError(
            "REPLICATE_API_TOKEN is not set. Add it to your .env — get one at "
            "https://replicate.com/account/api-tokens"
        )
    return {
        "Authorization": f"Bearer {settings.REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }


async def create_prediction(prompt: str) -> dict:
    """
    Kick off a video generation job. Returns the Replicate prediction object,
    which includes an `id` used to poll status later.

    NOTE: input fields (e.g. "prompt") vary by model. Check the model's page
    on replicate.com for its exact schema and adjust `payload` if you swap
    REPLICATE_MODEL for a different one.
    """
    url = f"{settings.REPLICATE_API_BASE}/models/{settings.REPLICATE_MODEL}/predictions"
    payload = {"input": {"prompt": prompt}}

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, headers=_headers(), json=payload)

    if resp.status_code >= 400:
        raise ReplicateError(f"Replicate API error {resp.status_code}: {resp.text}")

    return resp.json()


async def get_prediction(prediction_id: str) -> dict:
    url = f"{settings.REPLICATE_API_BASE}/predictions/{prediction_id}"

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=_headers())

    if resp.status_code >= 400:
        raise ReplicateError(f"Replicate API error {resp.status_code}: {resp.text}")

    return resp.json()


def extract_video_url(prediction: dict) -> str | None:
    """
    Replicate's `output` shape differs by model: sometimes a single URL
    string, sometimes a list, sometimes a dict with a named field. Handle
    the common cases; adjust if your chosen model differs.
    """
    output = prediction.get("output")
    if output is None:
        return None
    if isinstance(output, str):
        return output
    if isinstance(output, list) and output:
        return output[-1]
    if isinstance(output, dict):
        for key in ("video", "output", "url"):
            if key in output:
                return output[key]
    return None
