"""
Stripe subscription helpers.

Setup checklist (do this in the Stripe dashboard, test mode first):
1. Create a Product for Reelframe, with three recurring Prices
   (starter/studio/team, monthly). Copy each price_... ID into .env.
2. Add an endpoint at POST {your_domain}/billing/webhook, subscribed to at
   least: checkout.session.completed, customer.subscription.updated,
   customer.subscription.deleted, invoice.payment_succeeded. Copy the signing
   secret (whsec_...) into .env as STRIPE_WEBHOOK_SECRET.
3. For local dev, run `stripe listen --forward-to localhost:8000/billing/webhook`.
"""
import stripe

from ..config import settings

stripe.api_key = settings.STRIPE_SECRET_KEY

PLAN_TO_PRICE = {
    "starter": settings.STRIPE_PRICE_STARTER,
    "studio": settings.STRIPE_PRICE_STUDIO,
    "team": settings.STRIPE_PRICE_TEAM,
}
PRICE_TO_PLAN = {v: k for k, v in PLAN_TO_PRICE.items() if v}


def get_or_create_customer(user) -> str:
    if user.stripe_customer_id:
        return user.stripe_customer_id
    customer = stripe.Customer.create(email=user.email, metadata={"user_id": user.id})
    return customer.id


def create_checkout_session(user, plan: str) -> str:
    price_id = PLAN_TO_PRICE.get(plan)
    if not price_id:
        raise ValueError(f"Unknown or unconfigured plan: {plan}")

    customer_id = get_or_create_customer(user)

    session = stripe.checkout.Session.create(
        mode="subscription",
        customer=customer_id,
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=f"{settings.FRONTEND_URL}/dashboard.html?checkout=success",
        cancel_url=f"{settings.FRONTEND_URL}/index.html?checkout=cancelled",
        metadata={"user_id": user.id, "plan": plan},
    )
    return session.url


def create_portal_session(user) -> str:
    if not user.stripe_customer_id:
        raise ValueError("User has no Stripe customer yet")

    session = stripe.billing_portal.Session.create(
        customer=user.stripe_customer_id,
        return_url=f"{settings.FRONTEND_URL}/dashboard.html",
    )
    return session.url


def construct_event(payload: bytes, sig_header: str):
    return stripe.Webhook.construct_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)
