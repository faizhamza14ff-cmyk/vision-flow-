"""
Central configuration, loaded from environment variables (.env in local dev).
Copy .env.example to .env and fill in real values before running.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # --- Core ---
    APP_NAME: str = "Reelframe API"
    ENV: str = "development"
    FRONTEND_URL: str = "http://localhost:5500"

    # --- Database ---
    # Any SQLAlchemy URL works. Defaults to a local SQLite file so the app
    # runs with zero external setup; swap for Postgres in production, e.g.
    # postgresql+psycopg://user:pass@host:5432/reelframe
    DATABASE_URL: str = "sqlite:///./reelframe.db"

    # --- Auth ---
    JWT_SECRET: str = "change-me-to-a-long-random-string"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # --- Replicate (video generation) ---
    # Get a token at https://replicate.com/account/api-tokens
    REPLICATE_API_TOKEN: str = ""
    # Model + pinned version. Video model slugs/versions on Replicate change
    # often (see replicate.com/collections/wan-video for current options) —
    # verify this is still valid before going live, and swap it for whichever
    # model you actually want to serve.
    REPLICATE_MODEL: str = "wavespeedai/wan-2.1-t2v-720p"
    REPLICATE_API_BASE: str = "https://api.replicate.com/v1"

    # --- Stripe (subscriptions) ---
    # Get keys at https://dashboard.stripe.com/apikeys
    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    # Create these as recurring Prices in the Stripe dashboard, then paste
    # their price IDs (price_...) here. Each maps to a plan below.
    STRIPE_PRICE_STARTER: str = ""
    STRIPE_PRICE_STUDIO: str = ""
    STRIPE_PRICE_TEAM: str = ""

    # --- Plans ---
    # Seconds of rendered video included per billing cycle, per plan.
    PLAN_QUOTAS: dict = {
        "starter": 100,
        "studio": 900,
        "team": 3000,
    }


settings = Settings()

PRICE_TO_PLAN = {}  # populated lazily in billing router once settings load
