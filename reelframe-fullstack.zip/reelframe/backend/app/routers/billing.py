import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import settings
from ..deps import get_db, get_current_user
from ..services import stripe_service

router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/checkout", response_model=schemas.CheckoutOut)
def checkout(
    body: schemas.CheckoutRequest,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if body.plan not in settings.PLAN_QUOTAS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Unknown plan.")

    try:
        url = stripe_service.create_checkout_session(user, body.plan)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))

    # Persist the Stripe customer id as soon as it exists.
    if user.stripe_customer_id is None:
        cust_id = stripe_service.get_or_create_customer(user)
        user.stripe_customer_id = cust_id
        db.commit()

    return schemas.CheckoutOut(checkout_url=url)


@router.post("/portal", response_model=schemas.PortalOut)
def portal(user: models.User = Depends(get_current_user)):
    try:
        url = stripe_service.create_portal_session(user)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return schemas.PortalOut(portal_url=url)


@router.post("/webhook")
async def webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        event = stripe_service.construct_event(payload, sig_header)
    except Exception as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Invalid webhook signature: {e}")

    etype = event["type"]
    data = event["data"]["object"]

    if etype == "checkout.session.completed":
        user_id = data.get("metadata", {}).get("user_id")
        plan = data.get("metadata", {}).get("plan")
        sub_id = data.get("subscription")
        _upsert_subscription(db, user_id=user_id, plan=plan, stripe_subscription_id=sub_id,
                              status_="active")

    elif etype in ("customer.subscription.updated", "customer.subscription.deleted"):
        stripe_sub_id = data.get("id")
        sub = db.query(models.Subscription).filter(
            models.Subscription.stripe_subscription_id == stripe_sub_id
        ).first()
        if sub:
            sub.status = data.get("status", sub.status)
            period_end = data.get("current_period_end")
            if period_end:
                sub.current_period_end = dt.datetime.utcfromtimestamp(period_end)
            db.commit()

    elif etype == "invoice.payment_succeeded":
        stripe_sub_id = data.get("subscription")
        sub = db.query(models.Subscription).filter(
            models.Subscription.stripe_subscription_id == stripe_sub_id
        ).first()
        if sub:
            # New billing cycle — reset usage.
            sub.seconds_used = 0
            sub.status = "active"
            db.commit()

    return {"received": True}


def _upsert_subscription(db: Session, user_id: str, plan: str, stripe_subscription_id: str, status_: str):
    if not user_id:
        return
    sub = db.query(models.Subscription).filter(models.Subscription.user_id == user_id).first()
    if sub is None:
        sub = models.Subscription(user_id=user_id)
        db.add(sub)

    sub.plan = plan
    sub.status = status_
    sub.stripe_subscription_id = stripe_subscription_id
    sub.seconds_quota = settings.PLAN_QUOTAS.get(plan, 0)
    sub.seconds_used = 0
    db.commit()
