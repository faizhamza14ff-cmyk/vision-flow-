from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import models, schemas
from ..deps import get_db, require_active_subscription
from ..services import replicate_service

router = APIRouter(prefix="/generate", tags=["generate"])

# Flat per-clip cost charged against a plan's monthly quota. Replace with a
# real duration once you know your chosen model's typical output length, or
# read it back from the prediction after it succeeds.
SECONDS_PER_GENERATION = 5


@router.post("", response_model=schemas.GenerationOut)
async def create_generation(
    body: schemas.GenerationCreate,
    user: models.User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
):
    sub = user.subscription
    if sub.seconds_used + SECONDS_PER_GENERATION > sub.seconds_quota:
        raise HTTPException(
            status.HTTP_402_PAYMENT_REQUIRED,
            "You've used your plan's monthly render quota. Upgrade or wait for the next cycle.",
        )

    gen = models.Generation(user_id=user.id, prompt=body.prompt, status="starting")
    db.add(gen)
    db.commit()
    db.refresh(gen)

    try:
        prediction = await replicate_service.create_prediction(body.prompt)
    except replicate_service.ReplicateError as e:
        gen.status = "failed"
        gen.error = str(e)
        db.commit()
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(e))

    gen.replicate_prediction_id = prediction.get("id")
    gen.status = prediction.get("status", "processing")
    db.commit()
    db.refresh(gen)

    sub.seconds_used += SECONDS_PER_GENERATION
    db.commit()

    return gen


@router.get("", response_model=list[schemas.GenerationOut])
def list_generations(
    user: models.User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.Generation)
        .filter(models.Generation.user_id == user.id)
        .order_by(models.Generation.created_at.desc())
        .all()
    )


@router.get("/{generation_id}", response_model=schemas.GenerationOut)
async def get_generation(
    generation_id: str,
    user: models.User = Depends(require_active_subscription),
    db: Session = Depends(get_db),
):
    gen = (
        db.query(models.Generation)
        .filter(models.Generation.id == generation_id, models.Generation.user_id == user.id)
        .first()
    )
    if gen is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Generation not found.")

    # If still in flight, poll Replicate for the latest status.
    if gen.status in ("starting", "processing") and gen.replicate_prediction_id:
        try:
            prediction = await replicate_service.get_prediction(gen.replicate_prediction_id)
        except replicate_service.ReplicateError as e:
            gen.status = "failed"
            gen.error = str(e)
            db.commit()
            return gen

        gen.status = prediction.get("status", gen.status)
        if gen.status == "succeeded":
            gen.video_url = replicate_service.extract_video_url(prediction)
        elif gen.status == "failed":
            gen.error = prediction.get("error")
        db.commit()
        db.refresh(gen)

    return gen
